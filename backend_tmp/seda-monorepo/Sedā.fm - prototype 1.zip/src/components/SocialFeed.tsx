import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';

import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { 
  Heart, 
  MessageCircle, 
  Repeat, 
  Share,
  Play, 
  Pause, 
  Music,
  Clock,
  Crown,
  Users,
  Mic,
  UserPlus,
  UserMinus
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

const MOCK_FEED_DATA = [
  {
    id: 1,
    type: 'music_share',
    user: { 
      username: 'dj_nova', 
      displayName: 'DJ Nova',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=nova', 
      verified: true 
    },
    content: 'This track has been on repeat all week! Perfect vibes for late night sessions 🌙',
    track: {
      title: 'Midnight City',
      artist: 'M83',
      artwork: 'https://images.unsplash.com/photo-1583927109257-f21c74dd0c3f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFsYnVtJTIwY292ZXIlMjBlbGVjdHJvbmljfGVufDF8fHx8MTc1NTUyMzY3OHww&ixlib=rb-4.1.0&q=80&w=300',
      duration: '4:03'
    },
    timestamp: new Date(Date.now() - 300000),
    likes: 24,
    reposts: 3,
    comments: 8,
    isLiked: false,
    isReposted: false
  },
  {
    id: 2,
    type: 'text_post',
    user: { 
      username: 'beatmaster_99', 
      displayName: 'Beat Master',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=beatmaster' 
    },
    content: 'Just finished my first DJ set at the underground venue downtown! The crowd was absolutely electric. Thank you to everyone who showed up and vibed with me 🙏✨\n\nNext set: Friday 9PM at #ElectronicLounge',
    timestamp: new Date(Date.now() - 1800000),
    likes: 56,
    reposts: 12,
    comments: 23,
    isLiked: true,
    isReposted: false
  },
  {
    id: 3,
    type: 'dj_session',
    user: { 
      username: 'vinyl_collector', 
      displayName: 'Vinyl Collector',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=vinyl' 
    },
    content: 'Going live in 10 minutes! Tonight\'s theme: Classic house gems from the 90s 🏠',
    djSession: {
      title: 'Classic House Night',
      scheduledTime: new Date(Date.now() + 600000),
      expectedDuration: '2 hours',
      genre: 'House',
      listeners: 0
    },
    timestamp: new Date(Date.now() - 3600000),
    likes: 18,
    reposts: 7,
    comments: 15,
    isLiked: false,
    isReposted: true
  },
  {
    id: 4,
    type: 'music_share',
    user: { 
      username: 'synth_wave', 
      displayName: 'Synth Wave',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=synth' 
    },
    content: 'Found this hidden gem! Perfect for those chilly autumn nights 🍂',
    track: {
      title: 'Strobe',
      artist: 'Deadmau5',
      artwork: 'https://images.unsplash.com/photo-1629426958038-a4cb6e3830a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW55bCUyMHJlY29yZCUyMG11c2ljfGVufDF8fHx8MTc1NTQ4OTcyMnww&ixlib=rb-4.1.0&q=80&w=300',
      duration: '10:36'
    },
    timestamp: new Date(Date.now() - 7200000),
    likes: 31,
    reposts: 5,
    comments: 12,
    isLiked: false,
    isReposted: false
  },
  {
    id: 5,
    type: 'playlist_share',
    user: { 
      username: 'ambient_dreams', 
      displayName: 'Ambient Dreams',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ambient' 
    },
    content: 'Curated a new playlist for deep focus sessions. 2 hours of pure flow state ✨',
    playlist: {
      title: 'Deep Focus Flow',
      trackCount: 24,
      duration: '2h 17m',
      artwork: 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFtYmllbnQlMjBwbGF5bGlzdHxlbnwxfHx8fDE3NTU1MjM2Nzh8MA&ixlib=rb-4.1.0&q=80&w=300'
    },
    timestamp: new Date(Date.now() - 10800000),
    likes: 42,
    reposts: 18,
    comments: 6,
    isLiked: true,
    isReposted: false
  }
];

export function SocialFeed({ user, onNowPlaying, onStartDJ, posts = [], onFollowUser, onUnfollowUser, isFollowing }) {
  const [feedData, setFeedData] = useState([...posts, ...MOCK_FEED_DATA]);
  const [currentlyPlaying, setCurrentlyPlaying] = useState(null);
  const feedEndRef = useRef(null);

  // Update feed when new posts are added
  React.useEffect(() => {
    setFeedData([...posts, ...MOCK_FEED_DATA]);
  }, [posts]);

  useEffect(() => {
    // Auto-scroll to new posts
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [feedData]);

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = Math.floor((now - timestamp) / 1000);
    
    if (diff < 60) return `${diff}s`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
    return `${Math.floor(diff / 86400)}d`;
  };

  const handleLike = (postId) => {
    setFeedData(prev => prev.map(post => {
      if (post.id === postId) {
        const newIsLiked = !post.isLiked;
        return {
          ...post,
          isLiked: newIsLiked,
          likes: newIsLiked ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const handleRepost = (postId) => {
    setFeedData(prev => prev.map(post => {
      if (post.id === postId) {
        const newIsReposted = !post.isReposted;
        return {
          ...post,
          isReposted: newIsReposted,
          reposts: newIsReposted ? post.reposts + 1 : post.reposts - 1
        };
      }
      return post;
    }));
    
    toast.success('Reposted! Earned +2 DJ Points');
  };

  const handlePlayTrack = (track, postId) => {
    setCurrentlyPlaying({ ...track, postId });
    onNowPlaying({ ...track, postId, addedBy: feedData.find(p => p.id === postId)?.user });
    toast.success('Now playing! Earned +5 DJ Points');
  };

  const renderPost = (post) => {
    const isPlaying = currentlyPlaying?.postId === post.id;

    return (
      <Card key={post.id} className="border border-border hover:border-border shadow-sm hover:shadow-md transition-all duration-200 bg-card">
        <CardContent className="p-6">
          {/* User Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start gap-3">
              <Avatar className="w-11 h-11 shadow-sm">
                <AvatarImage src={post.user.avatar} />
                <AvatarFallback>{post.user.username[0].toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{post.user.displayName || post.user.username}</span>
                  {post.user.verified && <Crown className="w-4 h-4 text-ring" />}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>@{post.user.username}</span>
                  <span>•</span>
                  <span>{formatTimestamp(post.timestamp)}</span>
                </div>
              </div>
            </div>
            
            {/* Follow Button - Only show if not current user and follow functions exist */}
            {post.user.username !== user.username && onFollowUser && onUnfollowUser && isFollowing && (
              <div>
                {isFollowing(post.user.id) ? (
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs h-8 px-3"
                    onClick={() => onUnfollowUser(post.user.id)}
                  >
                    <UserMinus className="w-3 h-3 mr-1" />
                    Unfollow
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    className="text-xs h-8 px-3 bg-primary text-primary-foreground"
                    onClick={() => onFollowUser(post.user)}
                  >
                    <UserPlus className="w-3 h-3 mr-1" />
                    Follow
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Post Content */}
          <div className="mb-4">
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{post.content}</p>
          </div>

          {/* Media Content */}
          {post.type === 'music_share' && post.track && (
            <div className={`mb-4 p-4 bg-secondary/30 rounded-xl border-2 transition-all duration-200 ${isPlaying ? 'border-ring shadow-lg shadow-ring/10' : 'border-transparent'}`}>
              <div className="flex gap-4">
                <div className="relative group">
                  <img 
                    src={post.track.artwork} 
                    alt={post.track.title}
                    className="w-16 h-16 rounded-lg object-cover shadow-sm"
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    className="absolute inset-0 bg-black/50 hover:bg-black/70 border-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                    onClick={() => handlePlayTrack(post.track, post.id)}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium mb-1">{post.track.title}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{post.track.artist}</p>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{post.track.duration}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {post.type === 'dj_session' && post.djSession && (
            <div className="mb-4 p-4 bg-ring/10 rounded-xl border border-ring/20">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium mb-1 flex items-center gap-2">
                    <Mic className="w-4 h-4 text-ring" />
                    {post.djSession.title}
                  </h4>
                  <p className="text-sm text-muted-foreground mb-2">{post.djSession.genre} • {post.djSession.expectedDuration}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Users className="w-3 h-3" />
                    <span>{post.djSession.listeners} listening</span>
                  </div>
                </div>
                <Button size="sm" className="bg-ring text-ring-foreground hover:bg-ring/90">
                  Join Session
                </Button>
              </div>
            </div>
          )}

          {post.type === 'playlist_share' && post.playlist && (
            <div className="mb-4 p-4 bg-secondary/30 rounded-xl">
              <div className="flex gap-4">
                <img 
                  src={post.playlist.artwork} 
                  alt={post.playlist.title}
                  className="w-16 h-16 rounded-lg object-cover shadow-sm"
                />
                <div className="flex-1">
                  <h4 className="font-medium mb-1">{post.playlist.title}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{post.playlist.trackCount} tracks • {post.playlist.duration}</p>
                  <Button size="sm" variant="outline" className="text-xs">
                    <Play className="w-3 h-3 mr-1" />
                    Play Playlist
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Engagement Actions */}
          <div className="flex items-center justify-between pt-2 border-t border-border/50">
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                className={`text-xs h-8 px-3 ${post.isLiked ? 'text-destructive hover:text-destructive' : 'hover:text-destructive'}`}
                onClick={() => handleLike(post.id)}
              >
                <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-current' : ''}`} />
                {post.likes > 0 && <span>{post.likes}</span>}
              </Button>
              
              <Button variant="ghost" size="sm" className="text-xs h-8 px-3 hover:text-primary">
                <MessageCircle className="w-4 h-4 mr-2" />
                {post.comments > 0 && <span>{post.comments}</span>}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className={`text-xs h-8 px-3 ${post.isReposted ? 'text-chart-2 hover:text-chart-2' : 'hover:text-chart-2'}`}
                onClick={() => handleRepost(post.id)}
              >
                <Repeat className={`w-4 h-4 mr-2 ${post.isReposted ? 'fill-current' : ''}`} />
                {post.reposts > 0 && <span>{post.reposts}</span>}
              </Button>
            </div>
            
            <Button variant="ghost" size="sm" className="text-xs h-8 px-3 hover:text-primary">
              <Share className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="flex-1 flex flex-col max-w-2xl mx-auto">
      {/* Header */}
      <div className="p-6 border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <h1 className="text-xl font-medium">Home</h1>
        <p className="text-sm text-muted-foreground mt-1">Discover what your friends are sharing</p>
      </div>



      {/* Feed */}
      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {feedData.map(renderPost)}
          <div ref={feedEndRef} />
        </div>
      </ScrollArea>
    </div>
  );
}