import React from 'react';
import { motion } from 'motion/react';
import { 
  HeadphonesIcon, 
  Users, 
  Zap, 
  Heart,
  Upload,
  TrendingUp,
  DollarSign,
  Target,
  Shield
} from 'lucide-react';

const fanBenefits = [
  {
    icon: HeadphonesIcon,
    title: 'Real-time DJ Sessions',
    description: 'Join interactive DJ sessions with turn-based controls and crowd voting'
  },
  {
    icon: Users,
    title: 'Community Discovery',
    description: 'Find new music through trusted community recommendations and social feeds'
  },
  {
    icon: Zap,
    title: 'Live Music Events',
    description: 'Participate in exclusive listening parties and artist-hosted sessions'
  },
  {
    icon: Heart,
    title: 'Direct Artist Connection',
    description: 'Support and connect with artists in meaningful, authentic ways'
  }
];

const artistBenefits = [
  {
    icon: Upload,
    title: 'Direct Upload & Share',
    description: 'Upload your music directly and share with your community instantly'
  },
  {
    icon: TrendingUp,
    title: 'Real Audience Engagement',
    description: 'Build genuine connections with fans through interactive DJ sessions'
  },
  {
    icon: DollarSign,
    title: 'Fair Monetization',
    description: 'Set your own pricing with transparent 10% platform fee structure'
  },
  {
    icon: Target,
    title: 'Targeted Discovery',
    description: 'Reach the right audience through genre-based community channels'
  },
  {
    icon: Shield,
    title: 'Artist-First Platform',
    description: 'Built as a Public Benefit Company prioritizing artist and fan welfare'
  }
];

export function BenefitsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Benefits for Fans */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-medium text-foreground mb-8">
              Benefits for Fans
            </h2>
            <div className="space-y-6">
              {fanBenefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  className="flex gap-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary rounded-lg flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-foreground mb-2">
                      {benefit.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Benefits for Artists */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-medium text-foreground mb-8">
              Benefits for Artists
            </h2>
            <div className="space-y-6">
              {artistBenefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  className="flex gap-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary rounded-lg flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-foreground mb-2">
                      {benefit.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}