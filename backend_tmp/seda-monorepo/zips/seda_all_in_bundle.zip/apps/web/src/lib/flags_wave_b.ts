// lib/flags_wave_b.ts
export const FEATURE_SOCIAL = process.env.NEXT_PUBLIC_FEATURE_SOCIAL === "true";
export const FEATURE_LEADERBOARDS = process.env.NEXT_PUBLIC_FEATURE_LEADERBOARDS === "true";
export const FEATURE_TROPHY_CASE = process.env.NEXT_PUBLIC_FEATURE_TROPHY_CASE === "true";
