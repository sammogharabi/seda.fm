import React from 'react';
import { motion } from 'motion/react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../ui/accordion';

const faqs = [
  {
    question: "What makes sedā.fm a Public Benefit Company different?",
    answer: "As a PBC, we're legally required to balance profit with positive impact for our community. This means we prioritize artist welfare, fan experience, and platform sustainability over maximum shareholder returns. We publish annual benefit reports and can't change our mission without community input."
  },
  {
    question: "How does sedā.fm handle my personal data?",
    answer: "We collect only essential data needed for platform functionality. We don't sell your data, track you across the web, or build advertising profiles. You can export or delete your data anytime. Our privacy-first approach is built into our PBC charter."
  },
  {
    question: "What's included in Premium membership?",
    answer: "Premium members can host DJ sessions, access advanced playlist features, get priority support, early access to new features, enhanced discovery algorithms, and custom room creation. Premium also supports platform development and artist revenue sharing."
  },
  {
    question: "How do credits and points work?",
    answer: "Credits and points are earned through community participation like DJ sessions, curation, and engagement. They can be redeemed for Premium time and platform perks but cannot be converted to cash. This keeps the focus on community building rather than financial extraction."
  },
  {
    question: "Can I earn real money on sedā.fm?",
    answer: "Artists can earn real money through direct fan support and premium content, keeping 90% of revenue. Fans earn credits/points for engagement, but these are platform currency only, not convertible to cash."
  },
  {
    question: "How much do artists earn on sedā.fm?",
    answer: "Artists keep 90% of all revenue from fan payments and premium content. Our 10% fee covers platform costs, payment processing, and community development. There are no hidden fees, minimum thresholds, or complex algorithms affecting payouts."
  },
  {
    question: "How does fan pricing work?",
    answer: "Fans can choose to pay artists directly for track access or exclusive content. Artists can set suggested prices or let fans determine the amount. This creates a more direct and meaningful connection between artists and supporters."
  },
  {
    question: "Will there be ads on sedā.fm?",
    answer: "No traditional advertising. Our revenue comes from Premium subscriptions and optional fan-to-artist payments. This keeps the experience clean and ensures we're accountable to users, not advertisers."
  },
  {
    question: "When will the beta launch?",
    answer: "We're planning a limited beta launch in early 2024. Beta users will help us refine features and build the initial community. Sign up above to be notified when beta access opens."
  }
];

export function FAQSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-medium text-foreground mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Everything you need to know about sedā.fm, our mission, and how the platform works.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                viewport={{ once: true }}
              >
                <AccordionItem 
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-lg px-6 py-2 data-[state=open]:bg-card/80"
                >
                  <AccordionTrigger className="text-left hover:no-underline">
                    <span className="text-foreground font-medium pr-4">
                      {faq.question}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-4">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </motion.div>

        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="text-muted-foreground mb-4">
            Have more questions?
          </p>
          <a 
            href="mailto:hello@seda.fm" 
            className="text-primary hover:text-primary/80 transition-colors duration-200 font-medium"
          >
            Reach out to our team →
          </a>
        </motion.div>
      </div>
    </section>
  );
}