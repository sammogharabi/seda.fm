
  # Sedā.fm - prototype V.2

  This is a code bundle for Sedā.fm - prototype V.2. The original project is available at https://www.figma.com/design/OAqMHgkhrpoyl2baYs9jV4/Sed%C4%81.fm---prototype-V.2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  