// lib/flags.ts
export const FEATURE_PROFILES = process.env.NEXT_PUBLIC_FEATURE_PROFILES === "true";
export const FEATURE_PLAYLISTS = process.env.NEXT_PUBLIC_FEATURE_PLAYLISTS === "true";
