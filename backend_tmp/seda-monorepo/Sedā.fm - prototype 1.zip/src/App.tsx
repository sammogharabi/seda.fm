import React, { useState, useEffect } from 'react';
import { Toaster } from './components/ui/sonner';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { SocialFeed } from './components/SocialFeed';
import { DiscoverView } from './components/DiscoverView';
import { FollowingView } from './components/FollowingView';
import { ListeningView } from './components/ListeningView';
import { ChannelView } from './components/ChannelView';
import { UserProfile } from './components/UserProfile';
import { Leaderboards } from './components/Leaderboards';
import { Playlists } from './components/Playlists';
import { DJMode } from './components/DJMode';
import { NowPlaying } from './components/NowPlaying';
import { useIsMobile } from './components/ui/use-mobile';
import { MobileHeader } from './components/MobileHeader';
import { MobileNavigation } from './components/MobileNavigation';
import { CreatePostModal } from './components/CreatePostModal';
import { ComposeButton } from './components/ComposeButton';

export default function App() {
  const [user, setUser] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [currentView, setCurrentView] = useState('feed');
  const [currentChannel, setCurrentChannel] = useState('#hiphop');
  const [isDJMode, setIsDJMode] = useState(false);
  const [nowPlaying, setNowPlaying] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [userPosts, setUserPosts] = useState([]);
  const [followingList, setFollowingList] = useState([]);
  const [followersList, setFollowersList] = useState([]);
  const isMobile = useIsMobile();

  useEffect(() => {
    // Apply dark theme to document
    if (typeof document !== 'undefined') {
      document.documentElement.classList.add('dark');
      
      // Add viewport meta tag for PWA
      const viewportMeta = document.querySelector('meta[name="viewport"]');
      if (!viewportMeta) {
        const meta = document.createElement('meta');
        meta.name = 'viewport';
        meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';
        document.head.appendChild(meta);
      }
      
      // Add theme color meta tags
      const themeColorMeta = document.querySelector('meta[name="theme-color"]');
      if (!themeColorMeta) {
        const meta = document.createElement('meta');
        meta.name = 'theme-color';
        meta.content = '#000000';
        document.head.appendChild(meta);
      }
      
      // Add apple mobile web app meta tags
      const appleMobileWebAppCapable = document.querySelector('meta[name="apple-mobile-web-app-capable"]');
      if (!appleMobileWebAppCapable) {
        const meta = document.createElement('meta');
        meta.name = 'apple-mobile-web-app-capable';
        meta.content = 'yes';
        document.head.appendChild(meta);
      }
      
      const appleMobileWebAppStatusBarStyle = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
      if (!appleMobileWebAppStatusBarStyle) {
        const meta = document.createElement('meta');
        meta.name = 'apple-mobile-web-app-status-bar-style';
        meta.content = 'black-translucent';
        document.head.appendChild(meta);
      }
    }
    
    // Check for existing user session
    try {
      const savedUser = localStorage.getItem('seda_user');
      if (savedUser) {
        setUser(JSON.parse(savedUser));
      } else {
        setShowAuth(true);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      setShowAuth(true);
    }
  }, []);

  const handleLogin = (userData) => {
    try {
      setUser(userData);
      localStorage.setItem('seda_user', JSON.stringify(userData));
      setShowAuth(false);
    } catch (error) {
      console.error('Error saving user data:', error);
    }
  };

  const handleLogout = () => {
    try {
      setUser(null);
      localStorage.removeItem('seda_user');
      setShowAuth(true);
      setCurrentView('feed');
      setCurrentChannel('#hiphop');
      setIsDJMode(false);
      setNowPlaying(null);
      setUserPosts([]);
      setShowCreatePost(false);
      setFollowingList([]);
      setFollowersList([]);
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  const handleChannelSelect = (channel) => {
    setCurrentChannel(channel);
    setCurrentView('channel');
    // Exit DJ mode when switching channels
    if (isDJMode) {
      setIsDJMode(false);
    }
  };

  const handleViewChange = (view) => {
    setCurrentView(view);
    // Exit DJ mode when switching views
    if (isDJMode && view !== 'channel') {
      setIsDJMode(false);
    }
  };

  const handleStartDJ = () => {
    setIsDJMode(true);
  };

  const handleToggleDJ = () => {
    setIsDJMode(!isDJMode);
  };

  const handleExitDJ = () => {
    setIsDJMode(false);
  };

  const handleNowPlaying = (track) => {
    setNowPlaying(track);
  };

  const handleCreatePost = (newPost) => {
    setUserPosts(prev => [newPost, ...prev]);
  };

  const handleComposeClick = () => {
    setShowCreatePost(true);
  };

  const handleFollowUser = (userToFollow) => {
    setFollowingList(prev => {
      if (prev.find(u => u.id === userToFollow.id)) {
        return prev; // Already following
      }
      return [...prev, userToFollow];
    });
  };

  const handleUnfollowUser = (userId) => {
    setFollowingList(prev => prev.filter(u => u.id !== userId));
  };

  const isFollowing = (userId) => {
    return followingList.some(u => u.id === userId);
  };



  const renderMainContent = () => {
    if (isDJMode) {
      return (
        <DJMode 
          user={user}
          channel={currentChannel}
          onExit={handleExitDJ}
          onNowPlaying={handleNowPlaying}
        />
      );
    }

    switch (currentView) {
      case 'feed':
        return (
          <SocialFeed 
            user={user}
            onNowPlaying={handleNowPlaying}
            onStartDJ={handleStartDJ}
            posts={userPosts}
            onFollowUser={handleFollowUser}
            onUnfollowUser={handleUnfollowUser}
            isFollowing={isFollowing}
          />
        );
      case 'discover':
        return (
          <DiscoverView 
            user={user}
            onNowPlaying={handleNowPlaying}
            onFollowUser={handleFollowUser}
            onUnfollowUser={handleUnfollowUser}
            isFollowing={isFollowing}
            followingList={followingList}
          />
        );
      case 'following':
        return (
          <FollowingView 
            user={user} 
            followingList={followingList}
            onFollowUser={handleFollowUser}
            onUnfollowUser={handleUnfollowUser}
          />
        );
      case 'listening':
        return (
          <ListeningView 
            user={user}
            onNowPlaying={handleNowPlaying}
            onStartDJ={handleStartDJ}
          />
        );
      case 'channel':
        return (
          <ChannelView 
            channel={currentChannel}
            user={user}
            onStartDJ={handleStartDJ}
            onNowPlaying={handleNowPlaying}
          />
        );
      case 'profile':
        return <UserProfile user={user} />;
      case 'leaderboards':
        return <Leaderboards user={user} />;
      case 'playlists':
        return <Playlists user={user} />;
      default:
        return (
          <SocialFeed 
            user={user}
            onNowPlaying={handleNowPlaying}
            onStartDJ={handleStartDJ}
          />
        );
    }
  };

  // Show auth modal if no user
  if (!user) {
    return (
      <div className="min-h-screen bg-background dark">
        <AuthModal isOpen={showAuth} onLogin={handleLogin} />
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-secondary/10">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-primary-foreground font-medium text-lg">S</span>
              </div>
              <h1 className="text-3xl text-foreground font-medium">
                sedā.fm
              </h1>
            </div>
            <p className="text-muted-foreground text-lg">Welcome to the music community</p>
          </div>
        </div>
        <Toaster />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background dark flex flex-col">
      {/* Mobile Header */}
      {isMobile && (
        <MobileHeader 
          user={user}
          currentChannel={currentChannel}
          currentView={currentView}
          onChannelSelect={handleChannelSelect}
          onViewChange={handleViewChange}
          onLogout={handleLogout}
          isDJMode={isDJMode}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          onComposeClick={handleComposeClick}
        />
      )}
      
      {/* Main App Layout */}
      <div className="flex-1 flex">
        {/* Desktop Sidebar */}
        {!isMobile && (
          <Sidebar 
            user={user}
            currentChannel={currentChannel}
            currentView={currentView}
            onChannelSelect={handleChannelSelect}
            onViewChange={handleViewChange}
            onLogout={handleLogout}
            isDJMode={isDJMode}
            isMobile={false}
            onComposeClick={handleComposeClick}
            onFollowUser={handleFollowUser}
            followingList={followingList}
          />
        )}
        
        <main className={`flex-1 flex flex-col min-w-0 ${
          isMobile ? 'pb-16' : '' // Add bottom padding for mobile nav
        }`}>
          <div className={`flex-1 ${isMobile ? 'px-4 py-4 pb-safe' : ''}`}>
            {renderMainContent()}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      {isMobile && (
        <MobileNavigation 
          currentView={currentView}
          onViewChange={handleViewChange}
          isDJMode={isDJMode}
        />
      )}

      {/* Persistent Now Playing Bar */}
      {nowPlaying && (
        <div className={`${isMobile ? 'fixed bottom-16 left-0 right-0 z-30' : 'sticky bottom-0'}`}>
          <NowPlaying 
            track={nowPlaying}
            onToggleDJ={handleToggleDJ}
            isMobile={isMobile}
          />
        </div>
      )}

      {/* Mobile Floating Compose Button */}
      {isMobile && !isDJMode && (
        <ComposeButton onClick={handleComposeClick} isMobile={true} />
      )}

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={showCreatePost}
        onClose={() => setShowCreatePost(false)}
        onCreatePost={handleCreatePost}
        user={user}
      />

      <Toaster />
    </div>
  );
}