# AC_trophy_case (Given / When / Then)

## View trophies
- Given a user has earned trophies
- When I GET /trophies/:username
- Then I see a list of badges with earned dates in reverse chronological order
