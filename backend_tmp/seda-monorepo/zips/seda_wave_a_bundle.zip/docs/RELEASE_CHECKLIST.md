# RELEASE_CHECKLIST (Wave A)

- [ ] Run SQL migration on dev DB
- [ ] Set flags: NEXT_PUBLIC_FEATURE_PROFILES=false, NEXT_PUBLIC_FEATURE_PLAYLISTS=false
- [ ] Deploy API with routes for profiles & playlists
- [ ] Add E2E tests for Profile create/edit and Playlist create/add-item
- [ ] Enable flags for internal testers
