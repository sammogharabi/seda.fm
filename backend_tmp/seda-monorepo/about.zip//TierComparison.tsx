import React from 'react';
import { motion } from 'motion/react';
import { Check, X, Star, Zap } from 'lucide-react';
import { Button } from '../ui/button';

const features = [
  { name: 'Ads', free: true, premium: false, isNegative: true },
  { name: 'Join Rooms & Discovery', free: true, premium: true },
  { name: 'Follow Artists', free: true, premium: true },
  { name: 'Share Songs', free: true, premium: true },
  { name: 'Early Access', free: false, premium: true },
  { name: 'Supporter Badge', free: false, premium: true },
  { name: 'Earn Credits (to unlock Premium)', free: true, premium: false },
  { name: 'Earn Points (extend Premium)', free: false, premium: true }
];

interface TierComparisonProps {
  onSignup: () => void;
}

export function TierComparison({ onSignup }: TierComparisonProps) {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20">
      <div className="max-w-5xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-medium text-foreground mb-6">
            Free vs Premium
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Start free and upgrade when you're ready for advanced features. 
            Support the platform and unlock enhanced community tools.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Free Tier */}
          <motion.div 
            className="bg-card border border-border rounded-2xl p-8 shadow-lg"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-8">
              <div className="w-12 h-12 bg-gradient-to-br from-muted to-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-muted-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Free</h3>
              <p className="text-3xl font-medium text-foreground mb-2">
                $0<span className="text-lg text-muted-foreground">/month</span>
              </p>
              <p className="text-muted-foreground">
                Perfect for discovering music and joining the community
              </p>
            </div>
            
            <ul className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <motion.li 
                  key={feature.name}
                  className="flex items-center gap-3"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  viewport={{ once: true }}
                >
                  {feature.free ? (
                    feature.isNegative ? (
                      <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                    ) : (
                      <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                    )
                  ) : (
                    <X className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  )}
                  <span className={`text-base ${
                    feature.free 
                      ? feature.isNegative 
                        ? 'text-red-300' 
                        : 'text-foreground' 
                      : 'text-muted-foreground'
                  }`}>
                    {feature.name}
                  </span>
                </motion.li>
              ))}
            </ul>

            <Button 
              variant="outline" 
              className="w-full h-12 text-base font-medium"
              onClick={onSignup}
            >
              Start Free
            </Button>
          </motion.div>

          {/* Premium Tier */}
          <motion.div 
            className="bg-gradient-to-br from-primary/5 to-secondary border border-primary/30 rounded-2xl p-8 relative overflow-hidden shadow-lg"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="absolute top-4 right-4">
              <div className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                Ad-Free
              </div>
            </div>

            <div className="text-center mb-8">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-ring rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Premium</h3>
              <p className="text-3xl font-medium text-foreground mb-2">
                $9<span className="text-lg text-muted-foreground">/month</span>
              </p>
              <p className="text-muted-foreground">
                Full platform access with advanced community features
              </p>
            </div>
            
            <ul className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <motion.li 
                  key={feature.name}
                  className="flex items-center gap-3"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  viewport={{ once: true }}
                >
                  {feature.premium ? (
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                  ) : (
                    <X className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  )}
                  <span className={`text-base ${
                    feature.premium ? 'text-foreground' : 'text-muted-foreground'
                  }`}>
                    {feature.name}
                  </span>
                </motion.li>
              ))}
            </ul>

            <Button 
              className="w-full h-12 text-base font-medium bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={onSignup}
            >
              Start Premium Trial
            </Button>
          </motion.div>
        </div>

        {/* Credits & Points Callout */}
        <motion.div 
          className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-6 text-center max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <h4 className="text-lg font-bold text-foreground mb-3">
            About Credits & Points
          </h4>
          <p className="text-base text-muted-foreground leading-relaxed">
            <strong className="text-amber-400">Important:</strong> Credits and points earned on sedā.fm are not cash and cannot be 
            converted to real money. They can only be redeemed for Premium subscription time and platform perks.
          </p>
        </motion.div>
      </div>
    </section>
  );
}