import React from 'react';
import { Button } from './ui/button';
import { Home, Compass, Music, User } from 'lucide-react';

interface MobileNavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  isDJMode: boolean;
}

export function MobileNavigation({ currentView, onViewChange, isDJMode }: MobileNavigationProps) {
  if (isDJMode) return null;
  
  const navItems = [
    { id: 'feed', icon: Home, label: 'Feed' },
    { id: 'discover', icon: Compass, label: 'Discover' },
    { id: 'listening', icon: Music, label: 'Listening' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 mobile-safe-bottom">
      <div className="flex h-16 items-center justify-around px-2 min-h-[44px]">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              className={`flex flex-col gap-1 h-12 min-w-0 flex-1 ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
              onClick={() => onViewChange(item.id)}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs truncate">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}