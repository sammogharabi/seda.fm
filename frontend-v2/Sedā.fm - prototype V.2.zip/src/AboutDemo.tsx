import React from 'react';
import { AboutPage } from './components/AboutPage';

export default function AboutDemo() {
  return <AboutPage />;
}