import React from 'react';
import { motion } from 'motion/react';
import { 
  Radio, 
  Users, 
  FolderOpen, 
  Share2, 
  Upload, 
  Lock 
} from 'lucide-react';

const features = [
  {
    icon: Radio,
    title: 'Rooms',
    description: 'Join genre-based community rooms like #hiphop, #indie, or #electronic'
  },
  {
    icon: Users,
    title: 'DJ Sessions',
    description: 'Take turns DJing with real-time crowd voting and auto-skip functionality'
  },
  {
    icon: FolderOpen,
    title: 'Crates',
    description: 'Curate and organize your music collections with custom playlists'
  },
  {
    icon: Share2,
    title: 'Sharing',
    description: 'Share tracks instantly through social feeds and direct messages'
  },
  {
    icon: Upload,
    title: 'Artist Uploads',
    description: 'Artists can upload original music directly to the platform'
  },
  {
    icon: Lock,
    title: 'Privacy Controls',
    description: 'Granular privacy settings for your listening activity and social presence'
  }
];

export function HowItWorksSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-medium text-foreground mb-6">
            How sedā.fm Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Experience music socially through our innovative platform features designed 
            to bring fans and artists together in real-time.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="bg-card border border-border rounded-xl p-6 hover:border-primary/30 transition-colors duration-200"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <motion.div 
                className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary rounded-lg flex items-center justify-center mb-4"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ duration: 0.2 }}
              >
                <feature.icon className="w-6 h-6 text-primary" />
              </motion.div>
              <h3 className="text-lg font-medium text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="bg-card border border-border rounded-xl p-8 max-w-2xl mx-auto">
            <h3 className="text-xl font-medium text-foreground mb-4">
              Streaming-Agnostic Experience
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              sedā.fm works with your existing streaming services. Connect your Spotify, 
              Apple Music, or other platforms to share and discover music without switching apps.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}